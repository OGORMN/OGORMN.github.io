@echo off
rem Shortcut for the SERVER (the PC whose keyboard/mouse you share).
rem You usually don't need this — just double-click SynergyClone.exe and it
rem walks you through setup the first time. This is here if you prefer flags.
rem --side is which edge of THIS screen the other machine is on
rem (right / left / top / bottom). You can also change it live from the tray.
"%~dp0SynergyClone.exe" server --side right
pause
