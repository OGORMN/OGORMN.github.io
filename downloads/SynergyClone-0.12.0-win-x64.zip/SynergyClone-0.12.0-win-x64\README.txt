﻿SynergyClone 0.12.0 — Windows
Share one keyboard and mouse between two PCs on the same network.

Both PCs need this same build. No installer and no .NET install — it is one exe.

1. Extract this folder on each PC.
2. Double-click SynergyClone.exe.
3. On the PC you type on, choose Server and which side the other screen is on
   (left, right, top, or bottom).
4. On the other PC, choose Client. Leave the address blank and it will find
   the server on the network. You can also type the server's IP if you prefer.
5. If Windows Firewall asks, allow it on private networks.
6. Move the mouse off that edge of the server screen. It should appear on the
   other PC.

Ctrl+Alt+F12 on the server always brings the keyboard and mouse back.

The first run saves your answers to config.json next to the exe. After that,
double-clicking the exe just starts. A tray icon shows status: grey waiting,
green connected, blue while you are controlling the other PC.

Optional: set the same sharedKey in config.json on both PCs so only those two
machines can connect. The link is encrypted either way.
