@echo off
rem Shortcut for the CLIENT (the PC you want to control).
rem You usually don't need this — just double-click SynergyClone.exe and it
rem asks for the server's IP the first time. This is here if you prefer flags.
rem Replace the IP below with the server's LAN address (it prints this at start).
"%~dp0SynergyClone.exe" client --connect 192.168.0.20
pause
